# CS305 Park University
# Project Solution Code
# Game-Playing Agents

# implememntation of reversi
# https://www.mathsisfun.com/games/reversi.html

# For your project, you must complete the game search implementation (note the
# TODO comments below) as well as develop a competitve heuristic for your
# tournament entry. 

from masProblem import Node
from gameClient import GameClient
from gameClient import IllegalMove
from copy import deepcopy



starting_board = {
            'white': {(4, 4), (5, 5)},
            'black': {(4, 5), (5, 4)}
}     

            
def is_board_coordinate(c):
    return type(c) == int and c >= 1 and c <= 8

def is_board_coordinates(t):
    """Determines if t is a proper description of coordinates on the board
       First element is an integer between 1 and 8 representing the row
         (higher numbers are further up)
       Second element is an integer between 1 and 8 representing the column
         (higher numbers to the right)
    """
    return type(t) == tuple and len(t) == 2 and \
           is_board_coordinate(t[0]) and \
           is_board_coordinate(t[1])

class Reversi(Node):
    def __init__(self, isMax=True, move=None, prior_moves=[], newboard=starting_board):
        """Initializes the game node.
           isMax is True when it is white's turn and false when it is black's
           move is a 2-tuple of coordinates (from, to) as validated by is_coordinates
           prior_moves is a list of moves taken in the game so far
           newboard is a board dictionary determining piece locations (see starting_board)
           """
        super().__init__(str(move), isMax, None, None)
        self.prior_moves = [move] + prior_moves if move else []
        self.board = deepcopy(newboard)
        
        # process move if it is indicated
        if move:
            # validate move
            if not is_board_coordinates(move):
                raise IllegalMove("not a valid Chad move format")
            
            piece = self.tile_type(move)
            
            if piece != '.':
                raise IllegalMove("playing piece already at " + str(move))
            
            if move not in self.legal_moves():
                raise IllegalMove(('white' if isMax else 'black') + " player cannot legally move to " + str(move)) 
            
            # TODO: process placement / capture
            
            # add move to move history and flip turn
            self.move = move
            self.isMax = not self.isMax
            
            # skip turn if no moves
            if not list(self.legal_moves()):  
                self.isMax = not self.isMax
            
    def print_board(self):
        """prints a human-readable description of the board using
           the characters in tile_type (below)"""
        for r in range(8,0,-1):
            print(r, end=" ")
            for c in range(1,9):
                print(self.tile_type((r, c)), end="")
            print('')
        print('  12345678')
    
    def tile_type(self, p):
        """determines the type of tile.
             O - white piece 
             # - black piece
             . - unoccupied space
        """
        if p in self.board['white']:
            return 'O'
        elif p in self.board['black']:
            return '#'
        else:
            return '.'
    
    def occupied(self, p):
        """determines if a player's piece occupies this tile or not"""
        c = self.tile_type(p)
        return c != '.'          
    
    def isLeaf(self):
        """returns true of this is a leaf node"""
        # turn would have already been skipped if only one player had no moves
        return not list(self.legal_moves())
    
    def legal_moves(self):
        """determines all legal moves from this game state"""
        # TODO: generate all legal moves (2-tuple of board coordinates)
    
    def children(self):
        """computes child nodes for this node"""
        child_nodes = []
        for move in self.legal_moves():
            child_nodes.append(Reversi(self.isMax, move, self.prior_moves, self.board))
        return child_nodes
    
    def evaluate(self):
        """returns a heuristic value for this node"""
        # TODO: return 1 if player 1 wins, -1 if player 2 wins, and otherwise
        # a heuristic value between -1 and 1. 
        return 0

def main():
    c = GameClient(Reversi, None, None) # human vs human
    #c = GameClient(Reversi, None, Reversi) # human vs AI
    #c = GameClient(Reversi, Reversi, Reversi) # AI vs AI
    c.run_game()
    
if __name__ == '__main__':
    main()

