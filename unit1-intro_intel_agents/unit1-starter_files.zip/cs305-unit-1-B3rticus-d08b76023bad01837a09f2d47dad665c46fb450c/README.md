# CS305-Unit1-Assignment-Template
Template for CS305 Unit 1 Programming Assignment

Complete the instructions in the comments in a1.py and submit your work.
